# Mail & Google App Engine

This sample application demonstrates how to use [Mail with Google App Engine](https://cloud.google.com/appengine/docs/php/mail/).