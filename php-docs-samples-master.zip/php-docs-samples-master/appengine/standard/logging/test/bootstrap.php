<?php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/mocks/AppLogLine.php';
require_once __DIR__ . '/mocks/LogService.php';
require_once __DIR__ . '/mocks/RequestLog.php';
require_once __DIR__ . '/mocks/Functions.php';
