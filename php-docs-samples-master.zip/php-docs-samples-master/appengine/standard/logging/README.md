# Logging for App Engine (standard)

This app demonstrates how to read App Engine logs. Full instructions at [https://cloud.google.com/appengine/docs/php/logs/](https://cloud.google.com/appengine/docs/php/logs/)
