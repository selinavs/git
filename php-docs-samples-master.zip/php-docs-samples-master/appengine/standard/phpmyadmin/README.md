# A config file template for running phpmyadmin on App Engine Standard Environment

The source files in this directory are embeded in [Using phpMyAdmin with Google Cloud SQL on Google App Engine][phpmyadmin-guide]. Please refer to the document for how to use the config file.

[phpmyadmin-guide]: https://cloud.google.com/sql/docs/phpmyadmin-on-app-engine
