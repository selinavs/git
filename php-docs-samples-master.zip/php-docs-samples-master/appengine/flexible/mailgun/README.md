# Mailgun PHP Sample Application for App Engine Flexible Environment.

## Description

The sample code lives in [the standard directory](../../standard/mailgun).
Only two configuration files differ: `app.yaml` and `nginx-app.conf`.

Copy `app.yaml` and `nginx-app.conf` into [that directory](../../standard/mailgun),
then follow the instructions in the [README](../../standard/mailgun/README.md).

## Contributing changes

* See [CONTRIBUTING.md](../../../CONTRIBUTING.md)

## Licensing

* See [LICENSE](../../../LICENSE)


