# Mailjet PHP Sample Application for App Engine Flexible Environment.

## Description

The sample code lives in [the standard directory](../../standard/mailjet).
Only two configuration files differ: `app.yaml` and `nginx-app.conf`.

Copy `app.yaml` and `nginx-app.conf` into [that directory](../../standard/mailjet),
then follow the instructions in the [README](../../standard/mailjet/README.md).

## Contributing changes

* See [CONTRIBUTING.md](../../../CONTRIBUTING.md)

## Licensing

* See [LICENSE](../../../LICENSE)


