# Logging for Compute Engine

This app demonstrates how to log to Compute Engine from a PHP application. Full instructions at [https://cloud.google.com/error-reporting/docs/setting-up-on-compute-engine](https://cloud.google.com/error-reporting/docs/setting-up-on-compute-engine)
